# Opal Finance — Dependency & Environment Notes

## npm packages actually used by the accounting modules

| Package | Used by | Note |
|---|---|---|
| `axios` ^1.6 | xero-api, draft-invoice POST | the only HTTP client needed |
| `pg` ^8.10 | accounting-db, exceptions, db pool | no ORM — SQL is hand-written and tested |
| `express` ^4.18 | routes, server | Express 4: guard every async handler (see test inventory §4) |
| `express-session` ^1.17 | auth/session (rebuilt in new app) | pg-backed session store in source |
| `body-parser` ^1.20 | server | mount `express.raw` for the webhook BEFORE json |
| `bcryptjs` ^2.4 | auth (rebuilt) | password hashing |
| `uuid` ^11 | ids where not DB-generated | mostly `gen_random_uuid()` in SQL |
| `dotenv` ^16 | local env loading | |
| `helmet` ^8 | server hardening | keep |
| `cors` ^2.8 | server | lock to the app's own origin |

Dev/test: `jest`, `supertest`, plus a PG service container in CI.
Deploy-time additions in the source CI bundle: `applicationinsights@3`.
Security override carried in source `package.json`:
`"overrides": { "brace-expansion": "5.0.8" }` (zero-vuln audit gate).

NOT needed by accounting (scheduler-only — do not install):
`@microsoft/microsoft-graph-client`, `passport`, `passport-oauth2`,
`socket.io`, `socket.io-client`, `nodemailer`, `moment`.

## Environment variables (names only — values from Key Vault / owner)

| Var | Purpose |
|---|---|
| `DB_HOST/PORT/NAME/USER/PASSWORD/SSL` | Postgres |
| `SESSION_SECRET` | sessions (generate new) |
| `ENCRYPTION_KEY` | AES-256-GCM token encryption (generate NEW — never reuse the scheduler's) |
| `XERO_CLIENT_ID` / `XERO_CLIENT_SECRET` / `XERO_REDIRECT_URI` | NEW Xero app registration for Opal Finance |
| `XERO_WEBHOOK_KEY` | webhook HMAC (from the Xero app, when webhooks are enabled) |
| `SPLOSE_API_KEY` (or equivalent) | if the own-client Splose option is chosen |
| Feature flags | full fail-closed set in `docs/OPAL_FINANCE_SAFETY_MODEL.md` §1 |

Azure Key Vault secret names used by the source config script
(`deploy-reference/staging-xero-config.sh`): `xero-client-id`,
`xero-client-secret`, `xero-webhook-key`, `db-password`. Values are NOT in
this pack and must be provisioned fresh for Opal Finance.
