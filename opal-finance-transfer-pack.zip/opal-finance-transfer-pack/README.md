# Opal Finance — Transfer Pack

Complete handover for migrating the Accounting/Xero module out of the Opal
Therapy scheduling portal into a standalone app, **Opal Finance**.

- **Source**: `manixaan/opal-therapy-portal` @ `8c893bf` (2026-07-27)
- **Module state at export**: Phase 2 slice 1 complete — classification
  READY FOR STAGING REVIEW. 151 unit + 104 integration tests green, clean
  exits. All Xero write flags OFF. No Xero connection or write has ever
  occurred. Every finance table has zero rows — **no data migration needed**.
- **Contains NO secrets**: no .env values, no Xero/Azure credentials, no
  tokens, no client or financial data.

## Read in this order

1. `docs/OPAL_FINANCE_TRANSFER_HANDOVER.md` — what was built, what to
   reuse, what to rewrite, coupling map
2. `docs/OPAL_FINANCE_SAFETY_MODEL.md` — non-negotiable guarantees (all
   test-proven) that Opal Finance must reproduce
3. `docs/OPAL_FINANCE_TARGET_ARCHITECTURE.md` — recommended shape + port order
4. `docs/OPAL_FINANCE_CODE_EXTRACTION_MAP.md` — file-by-file portability
5. `docs/OPAL_FINANCE_SCHEMA_AND_MIGRATIONS.md` — 17 tables, the NULL-org
   dedupe repair, re-baselining guidance
6. `docs/OPAL_FINANCE_TEST_INVENTORY.md` — 67 tests + harness requirements
7. `docs/OPAL_FINANCE_NEW_PROJECT_MASTER_PROMPT.md` — paste into the new
   Claude project to start the build

## Layout

```
docs/                  7 transfer docs + reference/ (capability matrix,
                       Phase 2 plan, Xero setup + owner checklists)
backend/               10 accounting modules (6 portable as-is — see map)
backend/shared/        crypto-utils, permissions, logger, migrate runner —
                       copies for reference; rewrite/replace per the map
migrations/            004 + 006 (merge into the new app's 001_finance_core.sql)
tests/                 4 unit test files (39 tests, port unchanged)
tests/integration/     2 accounting itest files (28 tests) + helpers.js
frontend/              extracted accounting HTML section + JS module
                       (reference/spec for the new UI — do not port as-is)
deploy-reference/      staging-xero-config.sh (env-driven, no secret values)
DEPENDENCIES.md        npm packages + env vars the module needs
```

## Three rules before any code

1. Copy `backend/finance-flags.js` verbatim — the fail-closed double-gate
   write model is the heart of the safety story.
2. Generate NEW secrets everywhere (ENCRYPTION_KEY, session secret, Xero
   app registration with its own redirect URI). Never reuse the
   scheduler's.
3. Xero **Demo Company** sandbox before any real organisation; no pay-run
   code, ever; stop before any real Xero write.
