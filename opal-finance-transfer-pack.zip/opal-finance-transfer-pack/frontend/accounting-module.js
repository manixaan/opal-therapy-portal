/* ── Accounting module (owner-only) ─────────────────────────────────────────
   Backend enforces owner-only on every route; this also hides the tab and
   lazy-loads each sub-section from /api/accounting/*. */
window.acctState = { loaded: {} };

function acctFmtMoney(n, ccy) {
  if (n == null) return '—';
  try { return new Intl.NumberFormat('en-AU', { style: 'currency', currency: ccy || 'AUD' }).format(n); }
  catch (_) { return (ccy || 'AUD') + ' ' + Number(n).toFixed(2); }
}
async function acctGet(path) {
  const r = await fetch('/api/accounting' + path, { credentials: 'include' });
  if (r.status === 403 || r.status === 401) return { _denied: true };
  return r.json().catch(() => ({}));
}
async function acctPost(path, body) {
  const r = await fetch('/api/accounting' + path, {
    method: 'POST', credentials: 'include',
    headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}),
  });
  return { status: r.status, json: await r.json().catch(() => ({})) };
}

// Sub-section navigation
document.addEventListener('click', function (e) {
  var btn = e.target.closest && e.target.closest('#acct-subnav button');
  if (!btn) return;
  var key = btn.dataset.acct;
  document.querySelectorAll('#acct-subnav button').forEach(function (b) { b.classList.toggle('active', b === btn); });
  document.querySelectorAll('.acct-section').forEach(function (s) { s.classList.toggle('active', s.id === 'acct-' + key); });
  acctLoadSection(key);
});

async function acctLoadSection(key) {
  if (key === 'overview') return acctRenderOverview();
  if (key === 'exceptions') return acctRenderExceptions();
  if (key === 'connection') return acctRenderConnection();
  if (key === 'invoices') return acctRenderInvoices();
  if (key === 'candidates') return acctRenderCandidates();
  if (key === 'contacts') return acctRenderContacts();
  if (key === 'reconciliation') return acctRenderReconciliation();
  if (key === 'pricing') return acctRenderPricing();
  if (key === 'synclog') return acctRenderSyncLog();
}

// ── Exceptions (operational control centre) ─────────────────────────────
async function acctRenderExceptions(refresh) {
  var el = document.getElementById('acct-exceptions-body');
  var d = await acctGet('/exceptions' + (refresh ? '?refresh=true' : ''));
  if (d._denied) { el.innerHTML = '<div class="acct-note">Access denied.</div>'; return; }
  var rows = d.items || [];
  var badge = document.getElementById('acct-exc-count');
  if (badge) { badge.style.display = rows.length ? '' : 'none'; badge.textContent = rows.length; }
  var header = '<div style="margin-bottom:10px;display:flex;gap:8px;">' +
    '<button class="btn" onclick="acctRenderExceptions(true)">Re-scan now</button></div>';
  if (!rows.length) { el.innerHTML = header + '<div class="acct-note">No open exceptions. Everything that can be checked is clean.</div>'; return; }
  el.innerHTML = header + '<table class="acct-table"><thead><tr><th>Severity</th><th>Type</th><th>Affected</th><th>Explanation</th><th>Suggested action</th><th></th></tr></thead><tbody>' +
    rows.map(function (x) {
      return '<tr><td><span class="acct-sev ' + x.severity + '">' + x.severity + '</span></td>' +
        '<td><span class="acct-pill">' + String(x.exception_type || '').replace(/_/g, ' ') + '</span></td>' +
        '<td style="font-size:11px;color:var(--muted);">' + (x.affected_type || '') + '<br>' + String(x.affected_id || '').slice(0, 8) + '…</td>' +
        '<td style="font-size:12px;">' + (x.explanation || '') + '</td>' +
        '<td style="font-size:12px;color:var(--muted);">' + (x.suggested_action || '') + '</td>' +
        '<td style="white-space:nowrap;"><button class="btn" style="font-size:11px;" onclick="acctExceptionAction(\'' + x.id + '\',\'resolve\')">Resolve</button> ' +
        '<button class="btn" style="font-size:11px;" onclick="acctExceptionAction(\'' + x.id + '\',\'dismiss\')">Dismiss</button></td></tr>';
    }).join('') + '</tbody></table>';
}
async function acctExceptionAction(id, action) {
  var r = await acctPost('/exceptions/' + id + '/' + action, {});
  if (typeof showToast === 'function') showToast(r.status === 200 ? 'Exception ' + action + 'd' : 'Failed', r.json.error || '');
  acctRenderExceptions();
}

// ── Contacts / mappings ─────────────────────────────────────────────────
async function acctRenderContacts() {
  var el = document.getElementById('acct-contacts-body');
  var d = await acctGet('/contacts');
  if (d._denied) { el.innerHTML = '<div class="acct-note">Access denied.</div>'; return; }
  var rows = d.mappings || [];
  var gateOn = d.flags && d.flags.contactCreate;
  var header = '<div style="margin-bottom:10px;display:flex;gap:8px;align-items:center;">' +
    '<button class="btn" onclick="acctRefreshContactSuggestions(this)">Refresh suggestions</button>' +
    '<button class="btn ' + (gateOn ? '' : 'btn-locked') + '" ' + (gateOn ? '' : 'disabled') +
    ' title="' + (gateOn ? 'Create a missing contact in Xero' : 'Disabled: requires ENABLE_XERO_WRITE and ENABLE_XERO_CONTACT_CREATE') + '">Create contact in Xero 🔒</button>' +
    '<span style="font-size:11px;color:var(--muted);">' + (d.connected ? (d.xeroContactCount + ' Xero contacts synced') : 'Xero not connected') + '</span></div>';
  if (!rows.length) { el.innerHTML = header + '<div class="acct-note">No mappings yet. Sync Xero contacts, then refresh suggestions.</div>'; return; }
  el.innerHTML = header + '<table class="acct-table"><thead><tr><th>Splose client ID</th><th>Xero contact</th><th>Status</th><th>Confidence</th><th>Reason</th><th></th></tr></thead><tbody>' +
    rows.map(function (m) {
      return '<tr><td style="font-family:monospace;font-size:11px;">' + m.splose_client_id + '</td>' +
        '<td>' + (m.xero_contact_name || (m.xero_contact_id ? String(m.xero_contact_id).slice(0, 8) + '…' : '—')) + '</td>' +
        '<td><span class="acct-conf ' + m.status + '">' + String(m.status || '').replace(/_/g, ' ') + '</span></td>' +
        '<td>' + (m.match_confidence || '—') + '</td><td style="font-size:11px;color:var(--muted);">' + (m.match_reason || '—') + '</td>' +
        '<td>' + (m.status === 'mapped' ? '' :
          '<button class="btn" style="font-size:11px;" onclick="acctManualMap(\'' + m.id + '\',\'' + (m.xero_contact_id || '') + '\')">' +
          (m.xero_contact_id ? 'Confirm mapping' : 'Map manually') + '</button>') + '</td></tr>';
    }).join('') + '</tbody></table>';
}
async function acctRefreshContactSuggestions(btn) {
  btn.disabled = true; btn.textContent = 'Matching…';
  var r = await acctPost('/contacts/refresh-suggestions', {});
  btn.disabled = false; btn.textContent = 'Refresh suggestions';
  if (typeof showToast === 'function') showToast(r.status === 200 ? 'Suggestions refreshed' : 'Refresh failed',
    r.status === 200 ? JSON.stringify(r.json.summary || {}) : (r.json.error || ''));
  acctRenderContacts();
}
async function acctManualMap(id, suggestedXeroId) {
  var xeroId = prompt('Xero ContactID to map to this Splose client:', suggestedXeroId || '');
  if (!xeroId) return;
  var r = await acctPost('/contacts/' + id + '/map', { xeroContactId: xeroId.trim() });
  if (typeof showToast === 'function') showToast(r.status === 200 ? 'Mapping saved' : 'Mapping failed', r.json.error || '');
  acctRenderContacts();
}

async function acctRenderOverview() {
  var el = document.getElementById('acct-overview-cards');
  var d = await acctGet('/dashboard');
  if (d._denied) { el.innerHTML = '<div class="acct-note">Access denied.</div>'; return; }
  if (!d.connected) { el.innerHTML = '<div class="acct-note">Xero is not connected. Open <strong>Xero Connection</strong> to connect.</div>'; return; }
  var o = d.overview || {};
  var card = function (lbl, val) { return '<div class="acct-card"><div class="lbl">' + lbl + '</div><div class="val">' + val + '</div></div>'; };
  el.innerHTML =
    card('Revenue this month', acctFmtMoney(o.revenueThisMonth, o.currency)) +
    card('Outstanding', acctFmtMoney(o.outstandingBalance, o.currency)) +
    card('Unpaid invoices', (o.invoices && o.invoices.unpaid) || 0) +
    card('Overdue invoices', (o.invoices && o.invoices.overdue) || 0) +
    card('Paid invoices', (o.invoices && o.invoices.paid) || 0) +
    card('Draft invoices', (o.invoices && o.invoices.draft) || 0) +
    card('Avg invoice value', acctFmtMoney(o.averageInvoiceValue, o.currency)) +
    card('Uninvoiced candidates', o.uninvoicedCandidates || 0) +
    card('Needs mapping', o.candidatesNeedingMapping || 0) +
    card('Needs pricing', o.candidatesNeedingPricing || 0);
}

async function acctRenderConnection() {
  var s = await acctGet('/xero/status');
  var statusEl = document.getElementById('acct-conn-status');
  var badges = document.getElementById('acct-flag-badges');
  if (s._denied) { statusEl.textContent = 'Access denied.'; return; }
  if (!s.configured) {
    statusEl.innerHTML = '<strong>Xero is not configured on this environment.</strong> The owner must complete the Xero app setup (see deploy/XERO_OWNER_ACTIONS_CHECKLIST.md).';
  } else if (s.connected) {
    statusEl.innerHTML = 'Connected to <strong>' + (s.organisation && s.organisation.name || 'Xero') + '</strong>' +
      (s.baseCurrency ? ' · ' + s.baseCurrency : '') +
      '<br><span class="acct-pill">tenant …' + (s.organisation && s.organisation.tenantIdSuffix || '') + '</span>' +
      (s.lastConnectedAt ? ' <span style="color:var(--muted);font-size:12px;">since ' + new Date(s.lastConnectedAt).toLocaleDateString() + '</span>' : '');
  } else {
    statusEl.innerHTML = 'Not connected to Xero.';
  }
  document.getElementById('acct-connect-btn').style.display = (s.configured && !s.connected) ? '' : 'none';
  document.getElementById('acct-sync-btn').style.display = s.connected ? '' : 'none';
  document.getElementById('acct-disconnect-btn').style.display = s.connected ? '' : 'none';
  var f = s.flags || {};
  var flag = function (k, on) { return '<span class="acct-flag ' + (on ? 'on' : 'off') + '">' + k + ': ' + (on ? 'ON' : 'off') + '</span>'; };
  badges.innerHTML =
    flag('read', f.xeroRead) + flag('dashboard', f.financeDashboard) + flag('write', f.xeroWrite) +
    flag('draft-invoice', f.draftInvoiceCreate) + flag('approve', f.approveInvoice) +
    flag('send', f.sendInvoice) + flag('payment', f.paymentCreate) + flag('auto-recon', f.autoReconciliation) + flag('webhooks', f.webhooks);
}

async function acctConnectXero(btn) {
  btn.disabled = true; btn.textContent = 'Opening Xero…';
  try {
    var d = await acctGet('/xero/connect');
    if (d.authUrl) { window.location.href = d.authUrl; return; }
    throw new Error(d.error || 'Xero not configured');
  } catch (err) {
    btn.disabled = false; btn.textContent = 'Connect Xero';
    if (typeof showToast === 'function') showToast('Could not start Xero connection', String(err.message || err));
  }
}
async function acctSyncXero(btn) {
  btn.disabled = true; btn.textContent = 'Syncing…';
  var r = await acctPost('/xero/sync', {});
  btn.disabled = false; btn.textContent = 'Sync now';
  if (typeof showToast === 'function') showToast(r.status === 200 ? 'Xero sync complete' : 'Sync failed', r.status === 200 ? 'Finance data refreshed' : (r.json.error || ''));
  acctRenderOverview();
}
async function acctDisconnectXero(btn) {
  if (!confirm('Disconnect Xero? Cached finance data is kept but no further sync will occur.')) return;
  await acctPost('/xero/disconnect', {});
  acctRenderConnection();
}

async function acctRenderInvoices() {
  var el = document.getElementById('acct-invoices-body');
  var d = await acctGet('/xero/invoices');
  if (d._denied) { el.innerHTML = 'Access denied.'; return; }
  if (!d.connected) { el.innerHTML = '<div class="acct-note">Connect Xero to see invoices.</div>'; return; }
  var rows = (d.items || []).filter(function (i) { return i.type === 'ACCREC'; }).slice(0, 100);
  if (!rows.length) { el.innerHTML = '<div class="acct-note">No invoices synced yet. Use <strong>Sync now</strong> on the Xero Connection tab.</div>'; return; }
  el.innerHTML = '<table class="acct-table"><thead><tr><th>Number</th><th>Contact</th><th>Date</th><th>Due</th><th>Status</th><th>Total</th><th>Due amt</th></tr></thead><tbody>' +
    rows.map(function (i) {
      return '<tr><td>' + (i.invoice_number || '—') + '</td><td>' + (i.contact_name || '—') + '</td><td>' +
        (i.invoice_date ? String(i.invoice_date).slice(0, 10) : '—') + '</td><td>' + (i.due_date ? String(i.due_date).slice(0, 10) : '—') +
        '</td><td><span class="acct-pill">' + (i.status || '') + '</span></td><td>' + acctFmtMoney(i.total, i.currency_code) +
        '</td><td>' + acctFmtMoney(i.amount_due, i.currency_code) + '</td></tr>';
    }).join('') + '</tbody></table>';
}

async function acctRenderCandidates() {
  var el = document.getElementById('acct-candidates-body');
  var d = await acctGet('/candidates');
  if (d._denied) { el.innerHTML = 'Access denied.'; return; }
  var s = await acctGet('/xero/status');
  var draftOn = s.flags && s.flags.draftInvoiceCreate;
  var rows = d.candidates || [];
  var header = '<div style="margin-bottom:10px;"><button class="btn" onclick="acctGenerateCandidates(this)">Generate from Splose (next 30 days)</button>' +
    (draftOn ? '' : ' <span style="font-size:11px;color:var(--muted);">Draft-invoice creation is locked (ENABLE_XERO_WRITE + ENABLE_XERO_DRAFT_INVOICE_CREATE are off) — approval only records your decision.</span>') + '</div>';
  if (!rows.length) { el.innerHTML = header + '<div class="acct-note">No invoice candidates yet.</div>'; return; }
  el.innerHTML = header + '<table class="acct-table"><thead><tr><th>Appointment</th><th>Date</th><th>Status</th><th>Amount</th><th>Warnings</th><th></th></tr></thead><tbody>' +
    rows.map(function (c) {
      var actions = '';
      if (c.status === 'ready_for_review') {
        actions = '<button class="btn" style="font-size:11px;" onclick="acctReviewCandidate(\'' + c.id + '\',\'approved_for_draft\')">Approve</button> ' +
          '<button class="btn" style="font-size:11px;" onclick="acctReviewCandidate(\'' + c.id + '\',\'ignored\')">Ignore</button>';
      } else if (c.status === 'approved_for_draft') {
        actions = '<button class="btn ' + (draftOn ? '' : 'btn-locked') + '" style="font-size:11px;" ' + (draftOn ? '' : 'disabled') +
          ' title="' + (draftOn ? 'Create a DRAFT invoice in Xero (never authorised or sent)' : 'Disabled: requires ENABLE_XERO_WRITE and ENABLE_XERO_DRAFT_INVOICE_CREATE') + '"' +
          (draftOn ? ' onclick="acctCreateDraft(\'' + c.id + '\',this)"' : '') + '>Create draft in Xero 🔒</button>';
      } else if (c.status === 'draft_created_in_xero') {
        actions = '<span class="acct-pill">in Xero</span>';
      }
      return '<tr><td>' + (c.splose_appointment_id || '—') + '</td><td>' + (c.appointment_date ? String(c.appointment_date).slice(0, 10) : '—') +
        '</td><td><span class="acct-pill">' + c.status + '</span></td><td>' + acctFmtMoney(c.total_amount, c.currency_code) +
        '</td><td style="font-size:11px;color:var(--muted);">' + ((c.warnings || []).join(', ') || '—') +
        '</td><td style="white-space:nowrap;">' + actions + '</td></tr>';
    }).join('') + '</tbody></table>';
}
async function acctReviewCandidate(id, status) {
  var r = await acctPost('/candidates/' + id + '/review', { status: status });
  if (typeof showToast === 'function') showToast(r.status === 200 ? 'Candidate updated' : 'Update failed', r.json.error || '');
  acctRenderCandidates();
}
async function acctCreateDraft(id, btn) {
  if (!confirm('Create a DRAFT invoice in Xero for this candidate? It will never be authorised or sent by the portal.')) return;
  btn.disabled = true;
  var r = await acctPost('/candidates/' + id + '/create-draft-invoice', {});
  if (typeof showToast === 'function') showToast(r.status === 201 ? 'Draft created in Xero' : 'Draft creation blocked',
    r.status === 201 ? (r.json.invoiceNumber || '') : (r.json.error || ''));
  acctRenderCandidates();
}
async function acctGenerateCandidates(btn) {
  btn.disabled = true; btn.textContent = 'Generating…';
  var start = new Date().toISOString().slice(0, 10);
  var end = new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10);
  var r = await acctPost('/candidates/generate', { startDate: start, endDate: end });
  btn.disabled = false; btn.textContent = 'Generate from Splose (next 30 days)';
  if (typeof showToast === 'function') showToast(r.status === 200 ? 'Candidates generated' : 'Generation failed', r.status === 200 ? JSON.stringify(r.json.summary || {}) : (r.json.error || ''));
  acctRenderCandidates();
}

async function acctRenderReconciliation() {
  var el = document.getElementById('acct-recon-body');
  var d = await acctGet('/reconciliation');
  if (d._denied) { el.innerHTML = 'Access denied.'; return; }
  var rows = d.candidates || [];
  var header = '<div style="margin-bottom:10px;"><button class="btn" onclick="acctRefreshRecon(this)">Refresh suggestions</button></div>';
  if (!rows.length) { el.innerHTML = header + '<div class="acct-note">No reconciliation suggestions. Sync Xero, then refresh.</div>'; return; }
  el.innerHTML = header + '<table class="acct-table"><thead><tr><th>Type</th><th>Confidence</th><th>Payment</th><th>Invoice</th><th>Reasons</th></tr></thead><tbody>' +
    rows.map(function (c) {
      return '<tr><td><span class="acct-pill">' + c.match_type + '</span></td><td>' + c.confidence + '</td><td>' +
        acctFmtMoney(c.amount_payment) + '</td><td>' + acctFmtMoney(c.amount_invoice) + '</td><td style="font-size:11px;color:var(--muted);">' +
        ((c.reasons || []).join(', ')) + '</td></tr>';
    }).join('') + '</tbody></table>';
}
async function acctRefreshRecon(btn) {
  btn.disabled = true; btn.textContent = 'Refreshing…';
  await acctPost('/reconciliation/refresh', {});
  btn.disabled = false; btn.textContent = 'Refresh suggestions';
  acctRenderReconciliation();
}

async function acctRenderPricing() {
  var el = document.getElementById('acct-pricing-body');
  var d = await acctGet('/pricing-rules');
  if (d._denied) { el.innerHTML = 'Access denied.'; return; }
  var rows = d.rules || [];
  if (!rows.length) { el.innerHTML = '<div class="acct-note">No pricing rules configured. Rates are never guessed — add rules here before generating priced candidates.</div>'; return; }
  el.innerHTML = '<table class="acct-table"><thead><tr><th>Name</th><th>Service</th><th>Type</th><th>Funding</th><th>Rate</th><th>Tax</th><th>From</th></tr></thead><tbody>' +
    rows.map(function (r) {
      return '<tr><td>' + r.name + '</td><td>' + (r.splose_service_id || 'any') + '</td><td>' + (r.appointment_type || 'any') +
        '</td><td>' + (r.funding_type || 'any') + '</td><td>' + acctFmtMoney(r.unit_amount) + '</td><td>' + (r.tax_type || '') +
        '</td><td>' + (r.effective_from ? String(r.effective_from).slice(0, 10) : '') + '</td></tr>';
    }).join('') + '</tbody></table>';
}

async function acctRenderSyncLog() {
  var el = document.getElementById('acct-synclog-body');
  var d = await acctGet('/sync-log');
  if (d._denied) { el.innerHTML = 'Access denied.'; return; }
  var rows = d.log || [];
  if (!rows.length) { el.innerHTML = '<div class="acct-note">No sync activity yet.</div>'; return; }
  el.innerHTML = '<table class="acct-table"><thead><tr><th>Resource</th><th>Status</th><th>Records</th><th>When</th><th>Message</th></tr></thead><tbody>' +
    rows.map(function (r) {
      return '<tr><td>' + r.resource + '</td><td><span class="acct-pill">' + r.status + '</span></td><td>' + (r.records || 0) +
        '</td><td>' + new Date(r.created_at).toLocaleString() + '</td><td style="font-size:11px;color:var(--muted);">' + (r.message || '') + '</td></tr>';
    }).join('') + '</tbody></table>';
}

// Load overview when the Accounting tab is opened.
(function hookAccountingTab() {
  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('.tab[data-tab="accounting"]');
    if (t) setTimeout(function () { acctLoadSection('overview'); }, 50);
  });
})();
